﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using systemIO;

namespace systemIO
{
    class employee
    {
        public string emp_id, dept_id;
        public long phone;
        public string emp_name, email;
        public employee()
        {
            Console.WriteLine("enter employee ID(3 digits)");
            emp_id = Console.ReadLine();

            Console.WriteLine("enter employee name");
            emp_name = Console.ReadLine();

            Console.WriteLine("enter phone number");
            phone = long.Parse(Console.ReadLine());

            Console.WriteLine("enter department ID(3 digits)");
            dept_id = Console.ReadLine();

            Console.WriteLine("enter employee email ID");
            email = Console.ReadLine();

        }
        public override string ToString()
        {
            return (emp_id.PadLeft(20) + " | " + dept_id.ToString().PadLeft(20) +
                 " | " + emp_name.PadLeft(20) + " | "  + email.PadLeft(20) + " | " + phone.ToString().PadLeft(20)+"\n");
        }
        internal bool Presentinfile(string filename)
        {
            StreamReader reader = new StreamReader(filename);
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                
                if (line.Substring(0,20) == this.emp_id.PadLeft(20))
                {
                    reader.Close();
                    return false;
                }
            }
            reader.Close();
            return true;
        }
    }
}
