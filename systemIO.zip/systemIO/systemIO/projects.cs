﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace systemIO
{
    class projects
    {
        public string p_id, m_id;
        public string p_name;
        public projects()
        {
            Console.WriteLine("enter project ID (3 digits)");
            p_id = Console.ReadLine();

            Console.WriteLine("enter project name");
            p_name = Console.ReadLine();

            Console.WriteLine("enter manager ID (3 digits)");
            m_id= Console.ReadLine();

        }
        public override string ToString()
        {
            return (p_id.PadLeft(20) + " | " + m_id.PadLeft(20) + " | " + p_name.PadLeft(20)+"\n");
        }

        public bool Presentinfile(string filename2)
        {
            StreamReader reader = new StreamReader(filename2);
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                if (line.Substring(0, 20) == this.p_id.PadLeft(20))
                {
                    reader.Close();
                    return false;
                }
            }
            reader.Close();
            return true;
        }
    }
}


