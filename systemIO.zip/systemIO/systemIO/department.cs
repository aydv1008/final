﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace systemIO
{
    class department
    {
        public string dept_id, no_of_projects;
        public string dept_name;
        public department()
        {
            Console.WriteLine("enter department id (3 digits)");
            dept_id = Console.ReadLine();

            Console.WriteLine("enter department name");
            dept_name = Console.ReadLine();

            Console.WriteLine("enter number of projects");
            no_of_projects = Console.ReadLine();

        }
        public override string ToString()
        {
            return (dept_id.ToString().PadLeft(20) + " | " + dept_name.PadLeft(20) + " | " + no_of_projects.ToString().PadLeft(20));
        }
        public bool Presentinfile(string filename1)
        {
            StreamReader reader = new StreamReader(filename1);
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                if (line.Substring(0, 20) == this.dept_id.PadLeft(20))
                {
                    reader.Close();
                    return false;
                }
            }
            reader.Close();
            return true;
        }
    }
}
